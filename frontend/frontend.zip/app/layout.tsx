import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import "./global.css"
import { cn } from '@/lib/utils';
import { Providers } from './providers';
import { SonnerToaster as Toaster } from '@/components/ui/sonner'; // Corrected import path

// Configure Inter font
const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  weight: ['300', '400', '500', '600', '700', '800'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Micro Freelance Marketplace',
  description: 'Connect clients with freelancers for project-based work.',
  keywords: ['freelance', 'marketplace', 'tasks', 'gigs', 'remote work', 'hiring'],
  authors: [{ name: 'Your Name' }],
  openGraph: {
    title: 'Micro Freelance Marketplace',
    description: 'Connect clients with freelancers for project-based work.',
    url: 'https://your-marketplace.com',
    siteName: 'Micro Freelance Marketplace',
    images: [
      {
        url: 'https://your-marketplace.com/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Micro Freelance Marketplace',
      },
    ],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Micro Freelance Marketplace',
    description: 'Connect clients with freelancers for project-based work.',
    creator: '@your_twitter_handle',
    images: ['https://your-marketplace.com/twitter-image.jpg'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={cn('min-h-screen bg-background antialiased', inter.variable)}>
        <Providers>
          {children}
          <Toaster richColors position="top-right" />
        </Providers>
      </body>
    </html>
  );
}